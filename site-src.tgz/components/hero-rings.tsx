"use client"

import { motion } from "framer-motion"

export function HeroRings() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <motion.svg
        width="400"
        height="400"
        viewBox="0 0 400 400"
        className="absolute"
        initial={{ scale: 0.95, rotate: 0 }}
        animate={{ scale: 1, rotate: 2 }}
        transition={{
          duration: 20,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          ease: "easeInOut",
        }}
      >
        <circle cx="200" cy="200" r="150" fill="none" stroke="var(--ring)" strokeWidth="1" opacity="0.3" />
      </motion.svg>

      <motion.svg
        width="500"
        height="500"
        viewBox="0 0 500 500"
        className="absolute"
        initial={{ scale: 1.05, rotate: 0 }}
        animate={{ scale: 1, rotate: -1 }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          ease: "easeInOut",
        }}
      >
        <circle cx="250" cy="250" r="200" fill="none" stroke="var(--ring)" strokeWidth="1" opacity="0.2" />
      </motion.svg>
    </div>
  )
}
