"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Section } from "@/components/section"
import { CTASection } from "@/components/cta-section"
import { PostCard } from "@/components/post-card"
import { posts } from "@/data/posts"

export default function HomePage() {
  const latestPosts = posts.slice(0, 3)

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />

      <Section className="pt-32 pb-20 bg-gradient-to-br from-[var(--color-lilac-light)] to-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative animate-slide-up order-2 lg:order-1">
              {/* Golden circles around Natalia */}
              <div className="golden-circle golden-circle-1"></div>
              <div className="golden-circle golden-circle-2"></div>

              <div className="relative z-10">
                <div className="absolute -inset-4 bg-gradient-to-r from-[var(--color-lilac-bright)]/20 to-pink-200/30 rounded-3xl blur-2xl opacity-50"></div>
                <Image
                  src="/natalia-photo.png"
                  alt="Наталья Балышканова - профориентолог"
                  width={500}
                  height={600}
                  className="relative z-20 object-contain rounded-2xl"
                  priority
                />
              </div>
            </div>

            <div className="animate-fade-in order-1 lg:order-2">
              <Badge className="mb-6 glass-lilac text-slate-900 border-transparent hover:bg-[var(--color-lilac-bright)]/90 transition-all duration-300">
                Профориентолог
              </Badge>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 text-slate-900 leading-tight tracking-tight">
                Наталья
                <br />
                <span className="bg-gradient-to-r from-[var(--color-lilac-bright)] to-pink-500 bg-clip-text text-transparent">
                  Балышканова
                </span>
              </h1>

              <p className="text-xl md:text-2xl text-slate-600 mb-8 leading-relaxed max-w-lg">
                Помогаю найти призвание и построить карьеру мечты
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Button
                  size="lg"
                  className="glass-button bg-[var(--color-lilac-bright)]/80 hover:bg-[var(--color-lilac-bright)]/90 text-black px-8 py-4 rounded-xl font-medium transition-all duration-300 hover:scale-105 border-white/30"
                >
                  Записаться на консультацию
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="glass-button border-[var(--color-lilac-bright)]/50 text-[var(--color-lilac-bright)] hover:bg-[var(--color-lilac-bright)]/10 px-8 py-4 rounded-xl font-medium transition-all duration-300 bg-transparent"
                >
                  Узнать больше
                </Button>
              </div>

              <div className="glass-card rounded-2xl p-6 grid grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--color-lilac-bright)] mb-1">7+</div>
                  <div className="text-sm text-slate-600">лет опыта</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--color-lilac-bright)] mb-1">500+</div>
                  <div className="text-sm text-slate-600">клиентов</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-[var(--color-lilac-bright)] mb-1">95%</div>
                  <div className="text-sm text-slate-600">успеха</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      <Section className="py-20 relative" style={{ backgroundColor: "var(--color-beige)" }}>
        <div className="golden-circle-transition"></div>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-slate-900">Чем я помогаю</h2>
          <p className="text-xl text-slate-600 mb-16 max-w-2xl mx-auto">
            Профессиональная поддержка на каждом этапе карьерного пути
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Выбор профессии",
                description: "Помогу определить подходящее направление на основе ваших способностей и интересов",
              },
              {
                title: "Смена карьеры",
                description: "Поддержу в переходе к новой сфере деятельности с минимальными рисками",
              },
              {
                title: "Развитие карьеры",
                description: "Составлю план профессионального роста и достижения целей",
              },
            ].map((service, index) => (
              <Card
                key={service.title}
                className="glass-card hover:border-[var(--color-lilac-bright)]/30 transition-all duration-300 hover:shadow-lg hover:scale-105"
              >
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-slate-900">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Section>

      <Section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-slate-900">Как проходит работа</h2>
          </div>

          <div className="space-y-12">
            {[
              {
                step: "01",
                title: "Знакомство и диагностика",
                description: "Изучаем ваши интересы, способности и жизненные ценности",
              },
              {
                step: "02",
                title: "Анализ и планирование",
                description: "Определяем подходящие профессии и составляем план действий",
              },
              {
                step: "03",
                title: "Реализация и поддержка",
                description: "Сопровождаю вас на пути к новой карьере",
              },
            ].map((item, index) => (
              <div key={item.step} className="flex items-start gap-8">
                <div className="flex-shrink-0 w-16 h-16 glass-lilac text-white rounded-2xl flex items-center justify-center font-bold text-lg shadow-lg">
                  {item.step}
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-2xl font-bold text-slate-900 mb-3">{item.title}</h3>
                  <p className="text-lg text-slate-600 leading-relaxed">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section className="py-20" style={{ backgroundColor: "var(--color-beige-light)" }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-slate-900">Отзывы клиентов</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Анна К.",
                role: "Маркетолог",
                text: "Благодаря консультации смогла сменить карьеру с бухгалтерии на маркетинг. Теперь работаю с удовольствием!",
              },
              {
                name: "Максим Р.",
                role: "Студент IT",
                text: "Помогли определиться с выбором профессии. Сейчас учусь программированию и очень доволен.",
              },
              {
                name: "Екатерина М.",
                role: "Врач",
                text: "Долго не могла выбрать специализацию. Консультация помогла принять правильное решение.",
              },
            ].map((testimonial, index) => (
              <Card
                key={testimonial.name}
                className="glass-card hover:border-[var(--color-lilac-bright)]/30 transition-all duration-300 hover:scale-105"
              >
                <CardHeader>
                  <div className="flex items-center gap-1 mb-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <span key={i} className="text-yellow-400 text-sm">
                        ★
                      </span>
                    ))}
                  </div>
                  <CardTitle className="text-lg text-slate-900">{testimonial.name}</CardTitle>
                  <Badge variant="secondary" className="w-fit glass-lilac text-white border-transparent">
                    {testimonial.role}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 leading-relaxed">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Section>

      <Section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-slate-900">Полезные статьи</h2>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Практические советы по выбору профессии и развитию карьеры
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {latestPosts.map((post, index) => (
              <PostCard key={post.slug} post={post} />
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="outline"
              asChild
              className="border-slate-200 text-slate-700 hover:bg-slate-50 bg-transparent"
            >
              <Link href="/blog">Все статьи</Link>
            </Button>
          </div>
        </div>
      </Section>

      <CTASection
        title="Готовы найти свое призвание?"
        description="Запишитесь на консультацию и сделайте первый шаг к карьере мечты"
        buttonText="Записаться на консультацию"
        buttonHref="/contacts"
      />

      <SiteFooter />
    </div>
  )
}
